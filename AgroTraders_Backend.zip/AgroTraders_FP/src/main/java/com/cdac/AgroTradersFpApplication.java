package com.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroTradersFpApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(AgroTradersFpApplication.class, args);
		System.out.println("Hello AgroTraders");
	} 

}
