package com.cdac.repository;

import org.springframework.data.repository.CrudRepository;

import com.cdac.Entity.CartitemsClass;

public interface CartitemsRepo extends CrudRepository<CartitemsClass, Integer>{

}
