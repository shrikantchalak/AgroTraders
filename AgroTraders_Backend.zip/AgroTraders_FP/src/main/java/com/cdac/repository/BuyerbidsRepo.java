package com.cdac.repository;

import org.springframework.data.repository.CrudRepository;

import com.cdac.Entity.BuyerbidsClass;

public interface BuyerbidsRepo extends CrudRepository<BuyerbidsClass, Integer>{

}
