package com.cdac.repository;

import org.springframework.data.repository.CrudRepository;

import com.cdac.Entity.AgromedsClass;

public interface AgromedsRepo extends CrudRepository<AgromedsClass, Integer>{

}
