package com.cdac.repository;

import org.springframework.data.repository.CrudRepository;

import com.cdac.Entity.FertilizerdealerClass;

public interface FdealerRepo extends CrudRepository<FertilizerdealerClass , Integer> {

	
}
