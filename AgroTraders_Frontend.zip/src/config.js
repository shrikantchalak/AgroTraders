export const URL = "http://localhost:8081";

const config = {
  serverURL: "http://localhost:8081",
};

export default config;
